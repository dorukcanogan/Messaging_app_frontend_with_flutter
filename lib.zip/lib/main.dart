import 'package:flutter/material.dart';
import 'package:the_project/utils/color.dart';
import 'package:the_project/utils/style.dart';
import 'package:the_project/model/post.dart';


void main() {
  runApp(MaterialApp(
    title: 'IT535',
    home: Welcome(),
  ));
}

class Welcome extends StatelessWidget {
  const Welcome ({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My App', style: title),
        centerTitle: true,
        backgroundColor: AppColors.secondaryAppColor,
        elevation: 5,
    ),
      body: Text('hello', style: regularText),
        backgroundColor: AppColors.secondaryAppColor,
  );

  }
}
