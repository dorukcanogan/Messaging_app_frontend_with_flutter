class Post {
  int? postId;
  int? userId;
  String? postContent;
  String? postDate;
  int? postLikes;
  int? postComments;

  Post({
    this.postId,
    this.userId,
    this.postContent,
    this.postDate,
    this.postLikes,
    this.postComments
  });
}