import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryAppColor = Colors.black26;
  static const Color secondaryAppColor = Colors.white;

  static const Color textPrimaryColor = const Color(0xFF1C1C1C);
  static const Color textSecondaryColor = const Color(0xFF000000);
  static const Color successColor = Colors.green;

  static const Color warningColor = Colors.red;
}