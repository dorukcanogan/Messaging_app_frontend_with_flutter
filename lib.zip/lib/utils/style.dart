import 'package:flutter/material.dart';
import 'package:the_project/utils/color.dart';

final title = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.w900,
  color: AppColors.textPrimaryColor,
);

final regularText = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.w600,
  color: AppColors.primaryAppColor,
);

final subtitleText = TextStyle(
  fontSize: 16,
  fontWeight: FontWeight.w400,
  color: AppColors.textSecondaryColor,
);
